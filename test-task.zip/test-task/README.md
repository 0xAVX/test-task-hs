# PIXI.JS Project Template
This is a template for [PIXI.JS](https://www.pixijs.com) projects, including the webpack, webpack-cli and webpack-dev-server.

For up and running:
```
npm install
```

run dev server:
```
npm run start
```

build:
```
npm run build
```

Have fun :smile: